> 搞搞docker, 弄弄kubernetes,
>
> 学学golang, 写写shell。


### 一、 序

> **Your future depends on your dreams**

> **不要活在别人的眼里，不要活在别人的嘴里** 

> **要活在自己的心里，生活过的洒脱一点，不要为别人去活**


### 二、 工作状况

> **运维工程师**

> **热爱 Devops，对新技术充满好奇心**

> **目前就职于 Hedu 公司担任运维工程师**

