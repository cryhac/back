---
layout: post
title: Ubuntu Desktop
categories: Linux
description: Ubuntu Desktop
keywords: Linux
catalog:    true
header-img: "img/pexels/triangular.jpeg"
---


> Ubuntu 桌面版本折腾
> 生命不止 折腾不止


# Ubuntu Desktop 16.04

## 折腾完以后的界面

![ubuntu 界面][1]


  [1]: http://jicki.me/img/posts/ubuntu/ubuntu.png
