# 小炒肉

> 使用jekyll搭建的一个免费博客，作为镜像托管在Github上
>
> 博客主站点 [https://jicki.me](https://jicki.me) 镜像站点(同步更新) [http://jicki.github.io](http://jicki.github.io)
>
